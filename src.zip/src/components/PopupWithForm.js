import { Popup } from "./Popup.js";

export class PopupWithForm extends Popup {
  constructor(popupSelector, { callbackSubmitForm }) {
    super(popupSelector);
    this._callbackSubmitForm = callbackSubmitForm;
    this._formElement = this._popupItem.querySelector('.popup__form');
    this._inputList = this._formElement.querySelectorAll('.popup__input');
    this._buttonElement = this._formElement.querySelector('.popup__button');
  }

  _getInputValues(){
    
    this._inputValue = {};
    this._inputsList.forEach((input) => {
      inputValue[input.name] = input.value;
    });
     
    return this._inputValue;    
  }
  /*
  _getInputValues() {
    const inputValue = new Object();
    this._inputList.forEach((input) => {
     InputValue[input.name] = input.value;
    });
    return inputValue;
  }
*/
  setEventListeners() {
    super.setEventListeners();
    this._formElement.addEventListener("submit", (evt) => {
      evt.preventDefault();
      this._callbackSubmitForm(this._getInputValues());
    });
  }

  close() {
    super.close();
    this._formElement.reset();
  }
}
