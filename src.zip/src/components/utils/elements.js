export const editProfileButton =document.querySelector('.profile__editbutton');
export const userNameInput = document.querySelector('.popup__input_field_username');
export const userOccupationInput = document.querySelector('.popup__input_field_occupation');
export const userNameElement = document.querySelector('.profile__username');
export const userOccupationElement = document.querySelector('.profile__occupation');
export const formEditElement = document.getElementById('editForm');
export const addProfileButton =document.querySelector('.profile__addbutton');
export const addPopup =document.getElementById('addpopup');
export const editPopup =document.getElementById('editpopup');
export const photoPopup= document.getElementById('photopopup');
export const cardsContainer=document.querySelector('.elements');
export const formAddElement = document.getElementById('addForm');
export const mestoInput = document.querySelector('.popup__input_field_mesto');
export const linkInput = document.querySelector('.popup__input_field_link');
export const popupPhoto = document.querySelector('.popup__photo');
export const popupHeading = document.querySelector('.popup__heading');
export const template = document.querySelector('#mesto-template').content;
export const closeButtons = document.querySelectorAll('.popup__close');
export const popups = document.querySelectorAll('.popup');
export const initialCards = [
  {
    name: 'Архыз',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/arkhyz.jpg'
  },
  {
    name: 'Челябинская область',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/chelyabinsk-oblast.jpg'
  },
  {
    name: 'Иваново',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/ivanovo.jpg'
  },
  {
    name: 'Камчатка',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kamchatka.jpg'
  },
  {
    name: 'Холмогорский район',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kholmogorsky-rayon.jpg'
  },
  {
    name: 'Байкал',
    link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/baikal.jpg'
  }
];