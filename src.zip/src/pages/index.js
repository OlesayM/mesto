import {editProfileButton, userNameInput, userOccupationInput, userNameElement, userOccupationElement,
formEditElement, addProfileButton, addPopup, editPopup, photoPopup, formAddElement, mestoInput, 
linkInput, popupPhoto, popupHeading, template, closeButtons, popups, initialCards, cardsContainer}  from '../components/utils/elements.js';

import {Card} from '../components/Сard.js';
import {FormValidator} from '../components/FormValidator.js';
import {validationConfig} from '../components/utils/constants.js';
import {PopupWithImage} from '../components/PopupWithImage.js';
import {PopupWithForm} from '../components/PopupWithForm.js';
import {UserInfo} from '../components/UserInfo.js';
import {Section} from '../components/Section.js';

//инфо о пользователе
const profileInfo = new UserInfo({
  userNameSelector: '.profile__username',
  userOccupationSelector: '.profile__occupation',
});

const popupEditProfile = new PopupWithForm ('.popup_profile', {
  callbackSubmitForm: (userInfo) => {
    profileInfo.setUserInfo(userInfo/*{ userName: userInfo['username__form'], userOccupation: userInfo['occupation__form']}*/);
    popupEditProfile.close();
  },
});
popupEditProfile.setEventListeners();

editProfileButton.addEventListener('click', () => {
  const userData = profileInfo.getUserInfo();
  popupEditProfile.open();
  popupEditValidate.resetValidate();
  userNameInput.value = userData.userName;
  userOccupationInput.value = userData.userOccupation;
});


// валидация попапов
const popupEditValidate = new FormValidator(validationConfig, formEditElement);
popupEditValidate.enableValidation();
const popupAddValidate = new FormValidator(validationConfig, formAddElement);
popupAddValidate.enableValidation();

const renderedCard = new Section({
  items: initialCards,
  renderer: (item) => {
    const cardElement = createCard(item);
    renderedCard.addItem(cardElement);
  },
},
  ".elements"
); 
renderedCard.renderItems();

/*
//создание карточки
function createCard(item) {
  const cardElement = new Card(item, '#mesto-template');
  return cardElement.generateCard();
}*/

//Popup с картинкой
const popupZoomPhoto = new PopupWithImage('#photopopup');
popupZoomPhoto.setEventListeners();

function createCard(item) {
  const newCard = new Card(
    {
      data: item,
      handleCardClick: (name, link) => {
        popupZoomPhoto.open(name, link);
      },
    },
    '#mesto-template'
  )
  const cardElement = newCard.generateCard();
  return cardElement;
};
/*

const popupCardWithForm = new PopupWithForm('.popup_type_card', {
  callbackSubmitForm: (cardData) => {
    const newCard = createCard({name: cardData['form__name'], link: cardData['form__status']})
    standartCard.addItem(newCard);
    popupCardWithForm.close();
  },
});
popupCardWithForm.setEventListeners();


  //открывать попап с картинкой при клике на карточку
function handleCardClick (name, link) {
  popupZoomPhoto.open()
}



//создание карточки
function createCard(item) {
  const newCard = new Card(
    {
      data: item,
      handleCardClick: (name, link) => {
        popupZoomPhoto.open(name, link);
      },
    },
    ".elements__template"
  );
  const cardElement = newCard.generateCard();
  return cardElement;
}/*
//добавление карточки
function addCard(item) {
  const cardElement = createCard(item, '#mesto-template');
  cardsContainer.prepend(cardElement);
}
initialCards.forEach(addCard);


function handleCardAddSubmit(evt) {
  evt.preventDefault();
  const card = {
      name: mestoInput.value,
      link: linkInput.value,
      alt: mestoInput.value,
  };
  addCard(card);
  closePopup(addPopup);
  evt.target.reset();
  
}






//Popup с картинкой
const popupZoomPhoto = new PopupWithImage('#photopopup');
popupZoomPhoto.setEventListeners();

//инфо о пользователе
const userInformation = new UserInfo({
  userNameSelector: '.profile__name',
  userOccupationSelector: '.profile__description',
});

// валидация попапов
const popupEditValidate = new FormValidator(validationConfig, formEditElement);
popupEditValidate.enableValidation();
const popupAddValidate = new FormValidator(validationConfig, formAddElement);
popupAddValidate.enableValidation();




addProfileButton.addEventListener('click', function(){
  resetAddFormValid.resetValidate();
  openPopup(addPopup);
});

editProfileButton.addEventListener('click', function(){
  resetEditFormValid.resetValidate();
  openPopup(editPopup);
  userNameInput.value = userNameElement.textContent;
  userOccupationInput.value = userOccupationElement.textContent;
});

closeButtons.forEach(function(button){
  const popup = button.closest('.popup');
  button.addEventListener('click', () => closePopup(popup));
});

formEditElement.addEventListener('submit', submitEditProfileForm);
  
formAddElement.addEventListener('submit', handleCardAddSubmit);

const closeOverlayPopup = (evt) => {
  if (evt.target === evt.currentTarget) {
    const openForm = document.querySelector('.popup_open');
    closePopup(openForm);
  } 
}
popups.forEach(function(popup){
  popup.addEventListener('click', closeOverlayPopup);
});
*/
//открыть попап
function openPopup(popup) {
  popup.classList.add('popup_open');
  document.addEventListener("keydown", closeEscPopup);
}

//Закрыть попап
function closePopup(popup) {
  popup.classList.remove('popup_open');
  document.removeEventListener("keydown", closeEscPopup);
}
const closeEscPopup = (evt) => {
  if (evt.key === "Escape") {
    const popup = document.querySelector('.popup_open');
    closePopup(popup);
  }
}

//сабмит для формы редактирования
function submitEditProfileForm(evt){
  evt.preventDefault();
  userNameElement.textContent = userNameInput.value;
  userOccupationElement.textContent = userOccupationInput.value;
  closePopup(editPopup);
  }


/*
//добавление карточки
function addCard(item) {
  const cardElement = createCard(item, '#mesto-template');
  cardsContainer.prepend(cardElement);
}
initialCards.forEach(addCard);

*/
function handleCardAddSubmit(evt) {
  evt.preventDefault();
  const card = {
      name: mestoInput.value,
      link: linkInput.value,
      alt: mestoInput.value,
  };
  addCard(card);
  closePopup(addPopup);
  evt.target.reset();
  
}

addProfileButton.addEventListener('click', function(){
  resetAddFormValid.resetValidate();
  openPopup(addPopup);
});



closeButtons.forEach(function(button){
  const popup = button.closest('.popup');
  button.addEventListener('click', () => closePopup(popup));
});

formEditElement.addEventListener('submit', submitEditProfileForm);
  
formAddElement.addEventListener('submit', handleCardAddSubmit);

const closeOverlayPopup = (evt) => {
  if (evt.target === evt.currentTarget) {
    const openForm = document.querySelector('.popup_open');
    closePopup(openForm);
  } 
}
popups.forEach(function(popup){
  popup.addEventListener('click', closeOverlayPopup);
});